import{p as s}from"./CejuIrEN.js";const m=s("/images/jabama.svg");export{m as _};
