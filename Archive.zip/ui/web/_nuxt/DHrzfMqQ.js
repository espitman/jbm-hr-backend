import{p as s}from"./R59AZWGi.js";const m=s("/images/jabama.svg");export{m as _};
