import{c as t,o,A as r}from"./R59AZWGi.js";const n={__name:"empty",setup(a){return(e,s)=>(o(),t("div",null,[r(e.$slots,"default")]))}};export{n as default};
