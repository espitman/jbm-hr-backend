import{c as t,o,a4 as r}from"./Bi9Xi-du.js";const s={dir:"rtl"},_={__name:"empty",setup(a){return(e,c)=>(o(),t("div",s,[r(e.$slots,"default")]))}};export{_ as default};
