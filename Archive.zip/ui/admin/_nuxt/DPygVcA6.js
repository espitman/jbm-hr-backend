import{c as t,o,E as r}from"./DUgZ_HYD.js";const s={dir:"rtl"},_={__name:"empty",setup(a){return(e,c)=>(o(),t("div",s,[r(e.$slots,"default")]))}};export{_ as default};
