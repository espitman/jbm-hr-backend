import{c as t,o,G as r}from"./BJEvtXCT.js";const s={dir:"rtl"},_={__name:"empty",setup(a){return(e,c)=>(o(),t("div",s,[r(e.$slots,"default")]))}};export{_ as default};
