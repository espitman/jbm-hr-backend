import{v as s}from"./DSeZRhxd.js";const m=s("/images/jabama.svg");export{m as _};
