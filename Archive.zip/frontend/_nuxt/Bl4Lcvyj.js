import{c as t,o,E as r}from"./DSeZRhxd.js";const n={__name:"empty",setup(a){return(e,s)=>(o(),t("div",null,[r(e.$slots,"default")]))}};export{n as default};
